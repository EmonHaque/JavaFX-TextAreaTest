import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.stage.Screen;
import javafx.stage.Stage;

public class App extends Application {
    @Override
    public void start(Stage stage) {
        var area = new ETextArea(Icons.MultiText);
        var button = new Button("A Button for nothing");
        var vbox = new VBox(area, button);
        vbox.setPadding(new Insets(10));
        vbox.setSpacing(10);

//        var display = Screen.getScreens().get(1);
//        var bounds = display.getBounds();
//        stage.setX(bounds.getMinX() + (bounds.getWidth() - 400) / 2);
//        stage.setY(bounds.getMinY() + (bounds.getHeight() - 360) / 2);

        stage.setScene(new Scene(vbox, 400,360));
        stage.setTitle("Scratch");
        stage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}