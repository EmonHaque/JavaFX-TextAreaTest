import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class ETextArea extends BorderPane {
    TextArea input;
    SVGPath leftIcon, rightIcon;
    Text status;
    boolean isLoaded;
    double iconSize = 12;

    public ETextArea(String icon) {
        //setBackground(new Background(new BackgroundFill(Color.WHITE, null, null)));
        input = new TextArea();
        input.setBackground(null);
        //input.setBorder(null);
        //input.setBorder(new Border(new BorderStroke(Color.TRANSPARENT, Color.TRANSPARENT, Color.LIGHTBLUE,Color.TRANSPARENT, BorderStrokeStyle.NONE, BorderStrokeStyle.NONE,BorderStrokeStyle.SOLID,BorderStrokeStyle.NONE, null, null,null)));
        input.setWrapText(true);
        leftIcon = new SVGPath();
        leftIcon.setContent(icon);
        leftIcon.setFill(Color.BLUE);
        rightIcon = new SVGPath();
        rightIcon.setContent(Icons.Info);
        rightIcon.setFill(Color.CORAL);
        leftIcon.setScaleX(iconSize / leftIcon.prefWidth(-1));
        leftIcon.setScaleY(iconSize / leftIcon.prefHeight(-1));
        rightIcon.setScaleX(iconSize / rightIcon.prefWidth(-1));
        rightIcon.setScaleY(iconSize / rightIcon.prefHeight(-1));
        status = new Text("Text is required");
        status.setFill(Color.GRAY);
        status.setFont(Font.font(null, FontWeight.NORMAL, FontPosture.ITALIC, -1));
        setLeft(leftIcon);
        setRight(rightIcon);
        setCenter(input);
        setBottom(status);
        BorderPane.setAlignment(status, Pos.BOTTOM_RIGHT);
        input.setOnKeyTyped(this::onKeyPressed);
    }

    private void onKeyPressed(KeyEvent key) {
        var text = input.getText().trim();
        if(text.isEmpty()){
            rightIcon.setContent(Icons.Info);
            rightIcon.setFill(Color.CORAL);
            status.setText("Text is required");
        } else{
            rightIcon.setContent(Icons.Tick);
            rightIcon.setFill(Color.GREEN);
            status.setText(text.length() + " character entered");
        }
    }

    private void setScrollSkin(){
        var bar = (ScrollBar) input.lookup(".scroll-bar:vertical");
        bar.setSkin(new ScrollSkin(bar));
        bar.setPadding(new Insets(iconSize + 7,0,0,0));
        bar.setTranslateX(15.5);
        status.setTranslateX(-iconSize - 12);
    }
    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if(!isLoaded) {
            setScrollSkin();
            isLoaded = true;
        }
    }
}
