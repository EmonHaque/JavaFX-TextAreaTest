import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.ScrollBar;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.Separator;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.SVGPath;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class ETextArea extends BorderPane {
    TextArea input;
    ScrollBar fakeBar;
    SVGPath leftIcon, rightIcon;
    Text status;
    boolean isLoaded;
    double iconSize = 12;


    public ETextArea(String icon) {
        input = new TextArea();
        input.setBackground(null);
        input.setWrapText(true);
        leftIcon = new SVGPath();
        leftIcon.setContent(icon);
        leftIcon.setFill(Color.BLUE);
        rightIcon = new SVGPath();
        rightIcon.setContent(Icons.Info);
        rightIcon.setFill(Color.CORAL);
        leftIcon.setScaleX(iconSize / leftIcon.prefWidth(-1));
        leftIcon.setScaleY(iconSize / leftIcon.prefHeight(-1));
        rightIcon.setScaleX(iconSize / rightIcon.prefWidth(-1));
        rightIcon.setScaleY(iconSize / rightIcon.prefHeight(-1));
        fakeBar = new ScrollBar();
        fakeBar.setOrientation(Orientation.VERTICAL);
        fakeBar.setSkin(new ScrollSkin(fakeBar));
        status = new Text("Text is required");
        status.setFill(Color.GRAY);
        status.setFont(Font.font(null, FontWeight.NORMAL, FontPosture.ITALIC, -1));
        setLeft(leftIcon);

        var rightBox = new VBox(rightIcon, fakeBar);
        rightBox.setAlignment(Pos.TOP_CENTER);
        VBox.setVgrow(fakeBar, Priority.ALWAYS);
        setRight(rightBox);
        setCenter(input);

        var separator = new Separator();
        separator.setBorder(new Border(new BorderStroke(Color.LIGHTBLUE, Color.TRANSPARENT, Color.TRANSPARENT,Color.TRANSPARENT, BorderStrokeStyle.SOLID, BorderStrokeStyle.NONE,BorderStrokeStyle.NONE,BorderStrokeStyle.NONE, null, null, null)));
        var bottomBox = new VBox(separator, status);
        bottomBox.setAlignment(Pos.BOTTOM_RIGHT);
        setBottom(bottomBox);
        setMargin(bottomBox, new Insets(5,0,0,0));
        BorderPane.setAlignment(status, Pos.BOTTOM_RIGHT);
        input.setOnKeyTyped(this::onKeyPressed);
    }
    private void onKeyPressed(KeyEvent key) {
        var text = input.getText().trim();
        if(text.isEmpty()){
            rightIcon.setContent(Icons.Info);
            rightIcon.setFill(Color.CORAL);
            status.setText("Text is required");
        } else{
            rightIcon.setContent(Icons.Tick);
            rightIcon.setFill(Color.GREEN);
            status.setText(text.length() + " character entered");
        }
    }
    private void setScrollSkin(){
        var pane = (ScrollPane) input.lookup(".scroll-pane");
        pane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        pane.setVbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        var content = (Region) pane.getContent();
        content.setBackground(null);

        fakeBar.setVisible(false);
        fakeBar.minProperty().bind(pane.vminProperty());
        fakeBar.maxProperty().bind(pane.vmaxProperty());
        fakeBar.visibleAmountProperty().bind(pane.heightProperty().divide(content.heightProperty()));
        fakeBar.setUnitIncrement(0.1);
        pane.vvalueProperty().bindBidirectional(fakeBar.valueProperty());
        pane.vvalueProperty().addListener((observable, oldValue, newValue) -> {
            if(oldValue.doubleValue() == newValue.doubleValue()) {
                if(fakeBar.isVisible()) fakeBar.setVisible(false);
            }
            else {
                if(!fakeBar.isVisible()) fakeBar.setVisible(true);
            }
        });
    }
    @Override
    protected void layoutChildren() {
        super.layoutChildren();
        if(!isLoaded) {
            setScrollSkin();
            isLoaded = true;
        }
    }
}
